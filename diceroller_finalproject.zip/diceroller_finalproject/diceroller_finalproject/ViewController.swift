//
//  ViewController.swift
//  diceroller_finalproject
//
//  Created by Rissabubbles on 11/8/19.
//  Copyright © 2019 Razerware. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

